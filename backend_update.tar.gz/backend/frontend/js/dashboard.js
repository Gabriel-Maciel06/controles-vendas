/**
 * Dashboard (Resumo) Module — v3.0
 */

const MAP_COORD_CACHE = {
    "São Paulo": [-23.5505, -46.6333],
    "Campinas": [-22.9099, -47.0626],
    "Sorocaba": [-23.5015, -47.4581],
    "Jundiaí": [-23.1857, -46.8978],
    "Ribeirão Preto": [-21.1704, -47.8103],
    "Bauru": [-22.3145, -49.0605],
    "Santos": [-23.9618, -46.3322],
    "São José dos Campos": [-23.2237, -45.9009],
    "Osasco": [-23.5329, -46.7917],
    "Guarulhos": [-23.4628, -46.5333],
    "Praia Grande": [-24.0058, -46.4028],
    "Mogi das Cruzes": [-23.5200, -46.1852]
};

async function getCityCoords(city) {
    if (MAP_COORD_CACHE[city]) return MAP_COORD_CACHE[city];
    try {
        const res = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(city + ', SP, Brazil')}`);
        const data = await res.json();
        if (data && data.length > 0) {
            MAP_COORD_CACHE[city] = [parseFloat(data[0].lat), parseFloat(data[0].lon)];
            return MAP_COORD_CACHE[city];
        }
    } catch(e) {
        console.error("Geocoding failed for:", city, e);
    }
    // Fallback: slight random offset from SP center
    return [-23.55 + (Math.random() - 0.5)*2, -46.63 + (Math.random() - 0.5)*2];
}

const DashboardModule = {
    chartInstance: null,
    categoryChartInstance: null,

    fmt(val) {
        return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(val || 0);
    },

    init() {
        this.cacheDOM();
        this.bindEvents();
        this.loadGoal();
        this.update();
    },

    cacheDOM() {
        this.dom = {
            goalInput:       document.getElementById('goal-input'),
            btnSaveGoal:     document.getElementById('btn-save-goal'),
            goalRealized:    document.getElementById('goal-realized'),
            goalRemaining:   document.getElementById('goal-remaining'),
            goalProgressBar: document.getElementById('goal-progress-bar'),
            goalPercentage:  document.getElementById('goal-percentage'),
            avgTicket:       document.getElementById('stat-avg-ticket'),
            avgTicketChange: document.getElementById('stat-avg-ticket-change'),
            growth:          document.getElementById('stat-growth'),
            growthTrend:     document.getElementById('stat-growth-trend'),
            forecast:        document.getElementById('stat-forecast'),
            canvas:          document.getElementById('salesChart'),
            categoryCanvas:  document.getElementById('categoryChart'),
            categoryTitle:   document.getElementById('category-chart-title'),
            rankingBody:     document.getElementById('ranking-table-body'),
            crmCard:         document.getElementById('dash-crm-card'),
            samplesCard:     document.getElementById('dash-samples-card'),
            remindersCard:   document.getElementById('dash-reminders-card'),
            activitiesBody:  document.getElementById('dash-activities-body'),
            newClients:      document.getElementById('dash-new-clients'),
            newClientsBrk:   document.getElementById('dash-new-clients-breakdown'),
            contactGoal:     document.getElementById('dash-contact-goal'),
            contactsMade:    document.getElementById('dash-contacts-made'),
            contactsProg:    document.getElementById('dash-contacts-progress'),
            pipePosVenda:    document.getElementById('pipe-posvenda'),
            pipeFechamento:  document.getElementById('pipe-fechamento'),
            pipeMaturacao:   document.getElementById('pipe-maturacao'),
            pipeOferta:      document.getElementById('pipe-oferta'),
            pipeQualificacao:document.getElementById('pipe-qualificacao'),
            pipeContato:     document.getElementById('pipe-contato'),
            quickHotClients: document.getElementById('quick-hot-clients'),
            quickHotClosing: document.getElementById('quick-hot-closing'),
            quickSamples:    document.getElementById('quick-samples-pending'),
            quickSamplesLate:document.getElementById('quick-samples-late'),
            quickFollLate:   document.getElementById('quick-followups-late'),
            quickFollToday:  document.getElementById('quick-followups-today'),
            quickReactRate:  document.getElementById('quick-reactivation-rate'),
            quickReactCount: document.getElementById('quick-reactivation-count'),
        };
    },

    bindEvents() {
        this.dom.btnSaveGoal?.addEventListener('click', async () => {
            const val = parseFloat(this.dom.goalInput?.value) || 0;
            const currentSettings = await DataStore.getSettings() || {};
            await DataStore.saveSettings({
                ...currentSettings,
                crm_monthly_goal: val
            });
            alert('Meta do mês salva com sucesso!');
            this.loadGoal();
        });

        this.dom.contactGoal?.addEventListener('change', async (e) => {
            const val = parseInt(e.target.value) || 30;
            const currentSettings = await DataStore.getSettings() || {};
            await DataStore.saveSettings({
                ...currentSettings,
                crm_contact_goal: val
            });
            this.loadGoal();
        });

        const monthFilter = document.getElementById('global-month-filter');
        if (monthFilter && !monthFilter._boundDash) {
            const savedMonth = localStorage.getItem('crm_current_month');
            if (savedMonth) {
                monthFilter.value = savedMonth;
            } else if (!monthFilter.value) {
                const initDate = new Date();
                monthFilter.value = `${initDate.getFullYear()}-${String(initDate.getMonth()+1).padStart(2,'0')}`;
                localStorage.setItem('crm_current_month', monthFilter.value);
            }

            monthFilter.addEventListener('change', () => {
                localStorage.setItem('crm_current_month', monthFilter.value);
                this.update();
                if (window.SalesModule && typeof SalesModule.loadSales === 'function') {
                    SalesModule.loadSales();
                }
            });
            monthFilter._boundDash = true;
        }
    },

    async loadGoal() {
        this.settings = await DataStore.getSettings() || { crm_monthly_goal: 0, crm_contact_goal: 30 };
        
        if (this.dom.goalInput) {
            this.dom.goalInput.value = this.settings.crm_monthly_goal || 0;
        }
        
        if (this.dom.contactGoal) {
            this.dom.contactGoal.value = this.settings.crm_contact_goal || 30;
        }
        
        this.update();
    },

    update() {
        const sales     = DataStore.get(STORAGE_KEYS.SALES)     || [];
        const customers = DataStore.get(STORAGE_KEYS.CUSTOMERS) || [];
        const samples   = DataStore.get(STORAGE_KEYS.SAMPLES)   || [];
        const reminders = DataStore.get(STORAGE_KEYS.REMINDERS) || [];

        const monthFilter = document.getElementById('global-month-filter');
        let now;
        if (monthFilter && monthFilter.value) {
            const [y, m] = monthFilter.value.split('-');
            now = new Date(parseInt(y, 10), parseInt(m, 10) - 1, 15);
        } else {
            now = new Date();
        }

        const curPrefix     = `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}`;
        const lastMonthDate = new Date(now.getFullYear(), now.getMonth()-1, 1);
        const lastPrefix    = `${lastMonthDate.getFullYear()}-${String(lastMonthDate.getMonth()+1).padStart(2,'0')}`;

        this.updateGoalProgress(sales, curPrefix);
        this.updateAnalytics(sales, curPrefix, lastPrefix);
        this.updateCRMCard(customers);
        this.updateSamplesCard(samples);
        this.updateRemindersCard(reminders);
        this.updateActivities(customers, samples, reminders);
        this.updateRanking(sales);
        this.renderChart(sales);
        this.renderCategoryChart(sales, curPrefix);
        this.updateProspeccao(customers, curPrefix);
        this.updateQuickStats(customers, samples);
    },

    updateQuickStats(customers, samples) {
        if (!this.dom.quickHotClients) return;

        const profile = sessionStorage.getItem('maciel_profile') || 'default';
        const today = new Date().toISOString().split('T')[0];

        // 1. Clientes Quentes
        const hotArr = customers.filter(c => c.profile === profile && c.temperature === 'Quente');
        const closingArr = customers.filter(c => c.profile === profile && (c.temperature === 'Fechando' || c.status === 'Fechamento'));
        this.dom.quickHotClients.innerText = hotArr.length;
        this.dom.quickHotClosing.innerText = `Fechando: ${closingArr.length}`;

        // 2. Amostras Pendentes
        const pendingArr = samples.filter(s => s.profile === profile && (s.status === 'Enviada' || s.status === 'Em trânsito'));
        const lateArr = pendingArr.filter(s => s.estimatedReturn && s.estimatedReturn < today);
        this.dom.quickSamples.innerText = pendingArr.length;
        this.dom.quickSamplesLate.innerText = `Atrasadas: ${lateArr.length}`;

        // 3. Follow-ups
        const lateFollow = customers.filter(c => c.profile === profile && c.nextFollowUp && c.nextFollowUp < today);
        const todayFollow = customers.filter(c => c.profile === profile && c.nextFollowUp === today);
        this.dom.quickFollLate.innerText = lateFollow.length;
        this.dom.quickFollToday.innerText = `Hoje: ${todayFollow.length}`;

        // 4. Taxa de Reativação
        const inativos = customers.filter(c => c.profile === profile && c.origin === 'Inativo');
        const reativados = inativos.filter(c => c.temperature && c.temperature !== 'Frio' && c.temperature !== 'Primeiro contato');
        const rate = inativos.length > 0 ? Math.round((reativados.length / inativos.length) * 100) : 0;
        this.dom.quickReactRate.innerText = `${rate}%`;
        this.dom.quickReactCount.innerText = `${reativados.length} de ${inativos.length} reat.`;
    },

    updateProspeccao(customers, curPrefix) {
        if (!this.dom.newClients) return;
        
        let newCount = 0;
        let breakdown = { 'Google': 0, 'Inativo': 0, 'Prospec': 0, 'Maps': 0 };
        let contactedCount = 0;
        let pipe = { 'Pós venda': 0, 'Fechamento': 0, 'Maturação': 0, 'Primeira Oferta': 0, 'Qualificação': 0, 'Primeiro contato': 0 };

        customers.forEach(c => {
            const temp = c.temperature || 'Frio';
            if (pipe[temp] !== undefined) pipe[temp]++;
            
            // Assume the user creation relates to lastContactDate if no hard creation date logic
            if (c.createdAt && c.createdAt.startsWith(curPrefix)) {
                newCount++;
                const o = c.origin || 'Outros';
                if (breakdown[o] !== undefined) breakdown[o]++;
            } else if (!c.createdAt && c.lastContactDate && c.lastContactDate.startsWith(curPrefix)) {
                newCount++;
                const o = c.origin || 'Outros';
                if (breakdown[o] !== undefined) breakdown[o]++;
            }

            if (c.lastContactDate && c.lastContactDate.startsWith(curPrefix)) {
                contactedCount++;
            }
        });

        this.dom.newClients.innerText = newCount;
        this.dom.newClientsBrk.innerHTML = `
            <span style="background:rgba(129,140,248,0.2);color:#818cf8;padding:2px 6px;border-radius:4px;">🟣 Goo: ${breakdown['Google']}</span>
            <span style="background:rgba(29,158,117,0.2);color:#1D9E75;padding:2px 6px;border-radius:4px;">🟢 Ina: ${breakdown['Inativo']}</span>
            <span style="background:rgba(239,159,39,0.2);color:#EF9F27;padding:2px 6px;border-radius:4px;">🟠 Pro: ${breakdown['Prospec']}</span>
            <span style="background:rgba(136,136,136,0.2);color:#888;padding:2px 6px;border-radius:4px;">⚫ Map: ${breakdown['Maps']}</span>
        `;

        this.dom.contactsMade.innerText = contactedCount;
        const goalStr = this.dom.contactGoal?.value || localStorage.getItem('crm_contact_goal') || '30';
        const goal = parseInt(goalStr, 10) || 30;
        const pct = Math.min((contactedCount / goal) * 100, 100);
        if (this.dom.contactsProg) this.dom.contactsProg.style.width = pct + '%';

        if(this.dom.pipePosVenda)     this.dom.pipePosVenda.innerText     = pipe['Pós venda'];
        if(this.dom.pipeFechamento)   this.dom.pipeFechamento.innerText   = pipe['Fechamento'];
        if(this.dom.pipeMaturacao)    this.dom.pipeMaturacao.innerText    = pipe['Maturação'];
        if(this.dom.pipeOferta)       this.dom.pipeOferta.innerText       = pipe['Primeira Oferta'];
        if(this.dom.pipeQualificacao) this.dom.pipeQualificacao.innerText = pipe['Qualificação'];
        if(this.dom.pipeContato)      this.dom.pipeContato.innerText      = pipe['Primeiro contato'];

        // Trigger Prospec Map update specifically if available
        if (window.ProspecModule && ProspecModule.prospects) {
            this.updateProspecMap(ProspecModule.prospects);
        }
    },

    updateProspecMap(prospects) {
        // We will render map and KPIs if containers are introduced
        const kpisContainer = document.getElementById('dash-prospec-kpis');
        if (kpisContainer) {
            const total = prospects.length;
            const novas = prospects.filter(p => p.status === 'Novo').length;
            const enviadas = prospects.filter(p => p.status === 'Enviado').length;
            const cidades = [...new Set(prospects.map(p => p.city).filter(c => c))].length;
            const weekMs = Date.now() - 7 * 24 * 60 * 60 * 1000;
            const estaSemana = prospects.filter(p => new Date(p.createdAt).getTime() > weekMs).length;

            kpisContainer.innerHTML = `
                <div class="kpi-card" style="padding: 1rem;">
                    <div style="font-size:1.4rem;font-weight:700;color:var(--text-main);">${total}</div>
                    <div style="font-size:0.75rem;color:var(--text-muted);"><i class='bx bx-search'></i> Prospecções</div>
                    <div style="font-size:0.7rem;color:var(--accent);margin-top:0.2rem;">${novas} novas cadastradas</div>
                </div>
                <div class="kpi-card" style="padding: 1rem; border-left: 3px solid #1D9E75;">
                    <div style="font-size:1.4rem;font-weight:700;color:#1D9E75;">${enviadas}</div>
                    <div style="font-size:0.75rem;color:var(--text-muted);"><i class='bx bx-check-circle'></i> Enviadas CRM</div>
                    <div style="font-size:0.7rem;color:#1D9E75;margin-top:0.2rem;">Convertidas frio</div>
                </div>
                <div class="kpi-card" style="padding: 1rem;">
                    <div style="font-size:1.4rem;font-weight:700;color:var(--text-main);">${cidades}</div>
                    <div style="font-size:0.75rem;color:var(--text-muted);"><i class='bx bx-buildings'></i> Cidades</div>
                    <div style="font-size:0.7rem;color:var(--text-muted);margin-top:0.2rem;">Áreas prospectadas</div>
                </div>
                <div class="kpi-card" style="padding: 1rem;">
                    <div style="font-size:1.4rem;font-weight:700;color:var(--text-main);">${estaSemana}</div>
                    <div style="font-size:0.75rem;color:var(--text-muted);"><i class='bx bx-calendar'></i> Esta semana</div>
                    <div style="font-size:0.7rem;color:var(--text-muted);margin-top:0.2rem;">Trabalho recente</div>
                </div>
            `;
        }

        const mapContainer = document.getElementById('dash-prospec-map');
        if (mapContainer && prospects.length > 0) {
            // Conta prospects por cidade
            const cityCounts = {};
            prospects.forEach(p => {
                if(p.city) {
                    cityCounts[p.city] = cityCounts[p.city] || { total: 0, novas: 0, enviadas: 0 };
                    cityCounts[p.city].total++;
                    if(p.status === 'Novo') cityCounts[p.city].novas++;
                    if(p.status === 'Enviado') cityCounts[p.city].enviadas++;
                }
            });

            if (!this.prospecMap) {
                mapContainer.style.height = "350px";
                mapContainer.style.borderRadius = "12px";
                mapContainer.style.zIndex = "1";
                
                this.prospecMap = L.map('dash-prospec-map').setView([-23.5505, -46.6333], 7);
                
                L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
                    attribution: '&copy; OpenStreetMap contributors &copy; CARTO'
                }).addTo(this.prospecMap);
                
                this.prospecMapMarkers = L.layerGroup().addTo(this.prospecMap);
            }

            this.prospecMapMarkers.clearLayers();

            const drawMarkers = async () => {
                for(const [city, data] of Object.entries(cityCounts)) {
                    const coords = await getCityCoords(city);
                    const radius = Math.min(6 + data.total * 2, 20);
                    
                    const circle = L.circleMarker(coords, {
                        radius: radius,
                        fillColor: "rgba(29, 158, 117, 0.8)",
                        color: "rgba(29, 158, 117, 1)",
                        weight: 2,
                        opacity: 1,
                        fillOpacity: 0.6
                    }).addTo(this.prospecMapMarkers);
                    
                    circle.bindTooltip(`<div style="font-family: 'DM Sans', sans-serif;"><b>${city}</b><br>${data.total} prospecções<br>${data.novas} novas | ${data.enviadas} enviadas</div>`, {
                        direction: 'top'
                    });
                }
            };
            
            drawMarkers();
        }
    },

    updateGoalProgress(sales, curPrefix) {
        const curSales  = sales.filter(s => s.saleDate?.startsWith(curPrefix));
        const totalReal = curSales.reduce((s,v) => s+(parseFloat(v.value)||0), 0);
        const goal      = parseFloat(this.dom.goalInput?.value) || parseFloat(localStorage.getItem('crm_monthly_goal')) || 0;

        if (this.dom.goalRealized) this.dom.goalRealized.innerText = this.fmt(totalReal);

        if (goal > 0) {
            const pct        = Math.round((totalReal / goal) * 100);
            const displayPct = Math.min(pct, 100);
            if (this.dom.goalRemaining)   this.dom.goalRemaining.innerText   = this.fmt(Math.max(0, goal - totalReal));
            if (this.dom.goalProgressBar) {
                this.dom.goalProgressBar.style.width      = displayPct + '%';
                this.dom.goalProgressBar.style.background = pct >= 100
                    ? 'linear-gradient(90deg,#10b981 0%,#34d399 100%)'
                    : 'linear-gradient(90deg,var(--primary) 0%,#3b82f6 100%)';
            }
            if (this.dom.goalPercentage) this.dom.goalPercentage.innerText = pct + '%';
        } else {
            if (this.dom.goalRemaining)   this.dom.goalRemaining.innerText   = 'Defina a meta';
            if (this.dom.goalProgressBar) this.dom.goalProgressBar.style.width = '0%';
            if (this.dom.goalPercentage)  this.dom.goalPercentage.innerText  = '0%';
        }
    },

    updateAnalytics(sales, curPrefix, lastPrefix) {
        const curSales  = sales.filter(s => s.saleDate?.startsWith(curPrefix));
        const lastSales = sales.filter(s => s.saleDate?.startsWith(lastPrefix));
        const curTotal  = curSales.reduce((s,v) => s+(parseFloat(v.value)||0), 0);
        const lastTotal = lastSales.reduce((s,v) => s+(parseFloat(v.value)||0), 0);

        const avg = curSales.length > 0 ? curTotal / curSales.length : 0;
        if (this.dom.avgTicket) this.dom.avgTicket.innerText = this.fmt(avg);
        if (this.dom.avgTicketChange) {
            if (lastSales.length > 0) {
                const diff = avg - (lastTotal / lastSales.length);
                this.dom.avgTicketChange.innerText = (diff >= 0 ? '↑ ' : '↓ ') + this.fmt(Math.abs(diff)) + ' vs mês ant.';
                this.dom.avgTicketChange.className = 'stat-change ' + (diff >= 0 ? 'stat-up' : 'stat-down');
            } else {
                this.dom.avgTicketChange.innerText = 'Primeiro mês';
            }
        }

        if (this.dom.growth) {
            if (lastTotal > 0) {
                const growth = ((curTotal - lastTotal) / lastTotal) * 100;
                this.dom.growth.innerText = growth.toFixed(1) + '%';
                if (this.dom.growthTrend) {
                    this.dom.growthTrend.innerText = (growth >= 0 ? '↑' : '↓') + ' vs mês anterior';
                    this.dom.growthTrend.className = 'stat-change ' + (growth >= 0 ? 'stat-up' : 'stat-down');
                }
            } else {
                this.dom.growth.innerText = '--';
                if (this.dom.growthTrend) this.dom.growthTrend.innerText = 'Sem dados anteriores';
            }
        }

        if (this.dom.forecast) {
            const now      = new Date();
            const forecast = (curTotal / now.getDate()) * new Date(now.getFullYear(), now.getMonth()+1, 0).getDate();
            this.dom.forecast.innerText = this.fmt(isFinite(forecast) ? forecast : 0);
        }
    },

    updateCRMCard(customers) {
        if (!this.dom.crmCard) return;
        const today  = new Date().toISOString().split('T')[0];
        const latest = {};
        customers.forEach(c => {
            const name = c.name || c.client;
            const date = c.lastContactDate || '';
            if (!latest[name] || date > (latest[name].lastContactDate || '')) latest[name] = c;
        });
        const unique   = Object.values(latest);
        const overdue  = unique.filter(c => c.nextFollowUp && c.nextFollowUp < today).length;
        const dueToday = unique.filter(c => c.nextFollowUp === today).length;

        this.dom.crmCard.innerHTML = `
            <div style="font-size:0.85rem;font-weight:600;color:var(--text-main);margin-bottom:0.8rem;">👥 CRM / Follow-ups</div>
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:0.5rem;text-align:center;">
                <div style="background:rgba(255,255,255,0.04);border-radius:8px;padding:0.6rem 0.3rem;">
                    <div style="font-size:1.5rem;font-weight:700;color:var(--text-main);">${unique.length}</div>
                    <div style="font-size:0.7rem;color:var(--text-muted);">Clientes</div>
                </div>
                <div style="background:rgba(239,159,39,0.12);border-radius:8px;padding:0.6rem 0.3rem;">
                    <div style="font-size:1.5rem;font-weight:700;color:#EF9F27;">${dueToday}</div>
                    <div style="font-size:0.7rem;color:var(--text-muted);">Hoje</div>
                </div>
                <div style="background:rgba(226,75,74,0.12);border-radius:8px;padding:0.6rem 0.3rem;">
                    <div style="font-size:1.5rem;font-weight:700;color:#E24B4A;">${overdue}</div>
                    <div style="font-size:0.7rem;color:var(--text-muted);">Atrasados</div>
                </div>
            </div>`;
    },

    updateSamplesCard(samples) {
        if (!this.dom.samplesCard) return;
        const pending  = samples.filter(s => s.status === 'Enviada' || s.status === 'Pendente').length;
        const returned = samples.filter(s => s.status === 'Devolvida').length;

        this.dom.samplesCard.innerHTML = `
            <div style="font-size:0.85rem;font-weight:600;color:var(--text-main);margin-bottom:0.8rem;">📦 Amostras</div>
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:0.5rem;text-align:center;">
                <div style="background:rgba(255,255,255,0.04);border-radius:8px;padding:0.6rem 0.3rem;">
                    <div style="font-size:1.5rem;font-weight:700;color:var(--text-main);">${samples.length}</div>
                    <div style="font-size:0.7rem;color:var(--text-muted);">Total</div>
                </div>
                <div style="background:rgba(83,74,183,0.12);border-radius:8px;padding:0.6rem 0.3rem;">
                    <div style="font-size:1.5rem;font-weight:700;color:#9b94e8;">${pending}</div>
                    <div style="font-size:0.7rem;color:var(--text-muted);">Pendentes</div>
                </div>
                <div style="background:rgba(29,158,117,0.12);border-radius:8px;padding:0.6rem 0.3rem;">
                    <div style="font-size:1.5rem;font-weight:700;color:#1D9E75;">${returned}</div>
                    <div style="font-size:0.7rem;color:var(--text-muted);">Devolvidas</div>
                </div>
            </div>`;
    },

    updateRemindersCard(reminders) {
        if (!this.dom.remindersCard) return;
        const today   = new Date().toISOString().split('T')[0];
        const pending = reminders.filter(r => r.status !== 'Concluido' && r.status !== 'Concluído');
        const overdue = pending.filter(r => r.dateLimit < today).length;
        const alta    = pending.filter(r => r.priority === 'Alta').length;

        this.dom.remindersCard.innerHTML = `
            <div style="font-size:0.85rem;font-weight:600;color:var(--text-main);margin-bottom:0.8rem;">✅ Lembretes</div>
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:0.5rem;text-align:center;">
                <div style="background:rgba(255,255,255,0.04);border-radius:8px;padding:0.6rem 0.3rem;">
                    <div style="font-size:1.5rem;font-weight:700;color:var(--text-main);">${pending.length}</div>
                    <div style="font-size:0.7rem;color:var(--text-muted);">Pendentes</div>
                </div>
                <div style="background:rgba(226,75,74,0.12);border-radius:8px;padding:0.6rem 0.3rem;">
                    <div style="font-size:1.5rem;font-weight:700;color:#E24B4A;">${alta}</div>
                    <div style="font-size:0.7rem;color:var(--text-muted);">Alta prior.</div>
                </div>
                <div style="background:rgba(239,159,39,0.12);border-radius:8px;padding:0.6rem 0.3rem;">
                    <div style="font-size:1.5rem;font-weight:700;color:#EF9F27;">${overdue}</div>
                    <div style="font-size:0.7rem;color:var(--text-muted);">Atrasados</div>
                </div>
            </div>`;
    },

    updateActivities(customers, samples, reminders) {
        if (!this.dom.activitiesBody) return;
        const today  = new Date().toISOString().split('T')[0];
        const events = [];

        customers.slice(-6).forEach(c => {
            if (c.lastContactDate) events.push({
                date: c.lastContactDate, icon: '📞',
                text: `Contato com <strong>${c.name || c.client}</strong>`,
                sub: c.notes ? c.notes.substring(0,55) + (c.notes.length>55?'...':'') : ''
            });
        });

        samples.slice(-4).forEach(s => {
            events.push({
                date: s.sendDate || s.createdAt?.split('T')[0] || '', icon: '📦',
                text: `Amostra <strong>${s.product}</strong> → ${s.client}`,
                sub: `Status: ${s.status}`
            });
        });

        reminders
            .filter(r => r.status !== 'Concluido' && r.status !== 'Concluído' && r.dateLimit >= today)
            .sort((a,b) => a.dateLimit.localeCompare(b.dateLimit))
            .slice(0,3)
            .forEach(r => events.push({
                date: r.dateLimit,
                icon: r.priority === 'Alta' ? '🔴' : '🟡',
                text: r.title, sub: `Lembrete · ${r.priority}`
            }));

        events.sort((a,b) => (b.date||'').localeCompare(a.date||''));
        const recent = events.slice(0, 8);

        if (!recent.length) {
            this.dom.activitiesBody.innerHTML = `<tr><td colspan="3" style="text-align:center;padding:1.5rem;color:var(--text-muted);font-size:0.85rem;">Nenhuma atividade registrada ainda.</td></tr>`;
            return;
        }

        this.dom.activitiesBody.innerHTML = recent.map(ev => {
            const d = ev.date ? ev.date.split('-').reverse().join('/') : '-';
            const isToday = ev.date === today;
            return `<tr>
                <td style="font-size:1rem;text-align:center;padding:0.5rem 0.3rem;">${ev.icon}</td>
                <td style="padding:0.5rem 0.3rem;">
                    <div style="font-size:0.84rem;color:var(--text-main);">${ev.text}</div>
                    ${ev.sub ? `<div style="font-size:0.74rem;color:var(--text-muted);">${ev.sub}</div>` : ''}
                </td>
                <td style="font-size:0.77rem;color:${isToday?'#EF9F27':'var(--text-muted)'};white-space:nowrap;padding:0.5rem 0.3rem;">
                    ${isToday ? '🔔 Hoje' : d}
                </td>
            </tr>`;
        }).join('');
    },

    updateRanking(sales) {
        if (!this.dom.rankingBody) return;
        const totals = {};
        sales.forEach(s => {
            if (!s.client) return;
            totals[s.client] = (totals[s.client]||0) + (parseFloat(s.value)||0);
        });
        const sorted = Object.entries(totals).map(([name,total]) => ({name,total}))
            .sort((a,b) => b.total - a.total).slice(0,10);

        if (!sorted.length) {
            this.dom.rankingBody.innerHTML = `<tr><td colspan="3" style="text-align:center;padding:2rem;color:var(--text-muted);">Nenhuma venda registrada ainda.</td></tr>`;
            return;
        }
        this.dom.rankingBody.innerHTML = sorted.map((item,i) => {
            const medal = i===0?'🥇':i===1?'🥈':i===2?'🥉':`#${i+1}`;
            return `<tr>
                <td style="font-weight:bold;color:${i<3?'var(--warning)':'var(--text-muted)'};">${medal}</td>
                <td><strong>${item.name}</strong></td>
                <td>${this.fmt(item.total)}</td>
            </tr>`;
        }).join('');
    },

    renderChart(sales) {
        if (!this.dom.canvas) return;
        const monthly = {};
        sales.forEach(s => {
            if (!s.saleDate) return;
            const k = s.saleDate.substring(0,7);
            if (!monthly[k]) monthly[k] = {vendas:0,comissao:0};
            monthly[k].vendas   += parseFloat(s.value)||0;
            monthly[k].comissao += parseFloat(s.commission)||0;
        });
        const keys   = Object.keys(monthly).sort().slice(-6);
        const labels = keys.map(m => {
            const [y,mo] = m.split('-');
            return new Date(y,parseInt(mo)-1).toLocaleString('pt-BR',{month:'short'})+'/'+y.slice(2);
        });
        if (this.chartInstance) this.chartInstance.destroy();
        const primary = getComputedStyle(document.documentElement).getPropertyValue('--primary').trim()||'#6366f1';
        const accent  = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() ||'#10b981';
        this.chartInstance = new Chart(this.dom.canvas.getContext('2d'), {
            type:'line',
            data:{
                labels: labels.length?labels:['Sem dados'],
                datasets:[
                    {label:'Vendas (R$)',data:keys.length?keys.map(k=>monthly[k].vendas):[0],
                     borderColor:primary,backgroundColor:'transparent',borderWidth:3,tension:0.3,pointBackgroundColor:primary,yAxisID:'y'},
                    {label:'Comissão (R$)',data:keys.length?keys.map(k=>monthly[k].comissao):[0],
                     borderColor:accent,backgroundColor:'transparent',borderWidth:2,borderDash:[5,5],tension:0.3,pointBackgroundColor:accent,yAxisID:'y1'}
                ]
            },
            options:{
                responsive:true,maintainAspectRatio:false,
                interaction:{mode:'index',intersect:false},
                plugins:{
                    tooltip:{callbacks:{label:ctx=>ctx.dataset.label+': '+this.fmt(ctx.parsed.y)}},
                    legend:{labels:{color:'#94a3b8'}}
                },
                scales:{
                    x:{grid:{color:'rgba(255,255,255,0.05)'},ticks:{color:'#94a3b8'}},
                    y:{type:'linear',position:'left',grid:{color:'rgba(255,255,255,0.05)'},
                       ticks:{color:'#94a3b8',callback:v=>'R$ '+(v>=1000?(v/1000).toFixed(1)+'k':v)}},
                    y1:{type:'linear',position:'right',grid:{drawOnChartArea:false},ticks:{color:accent}}
                }
            }
        });
    },

    renderCategoryChart(sales, curPrefix) {
        if (!this.dom.categoryCanvas) return;
        const curSales = sales.filter(s => s.saleDate?.startsWith(curPrefix));
        const profile = sessionStorage.getItem('maciel_profile');
        const dataMap  = {};

        if (profile === 'mamae') {
            if (this.dom.categoryTitle) this.dom.categoryTitle.innerText = 'Lucro por Vinho (Este Mês)';
            curSales.forEach(s => {
                const label = s.productName || 'Outros';
                dataMap[label] = (dataMap[label] || 0) + (parseFloat(s.commission) || 0);
            });
        } else {
            if (this.dom.categoryTitle) this.dom.categoryTitle.innerText = 'Performance por Canal (Este Mês)';
            curSales.forEach(s => {
                const label = s.type || 'Normal';
                dataMap[label] = (dataMap[label] || 0) + (parseFloat(s.value) || 0);
            });
        }

        const labels = Object.keys(dataMap);
        const values = Object.values(dataMap);
        if (this.categoryChartInstance) this.categoryChartInstance.destroy();
        this.categoryChartInstance = new Chart(this.dom.categoryCanvas.getContext('2d'), {
            type:'doughnut',
            data:{
                labels:labels.length?labels:['Sem dados'],
                datasets:[{data:values.length?values:[1],
                    backgroundColor:['#6366f1','#10b981','#f59e0b','#ef4444','#8b5cf6','#ec4899'],borderWidth:0}]
            },
            options:{responsive:true,maintainAspectRatio:false,
                plugins:{legend:{position:'bottom',labels:{color:'#94a3b8',padding:20}}},cutout:'70%'}
        });
    }
};

window.DashboardModule = DashboardModule;

document.addEventListener('DataStoreReady', () => {
    DashboardModule.init();
});
